import * as path from 'path';
import * as zlib from 'zlib';
import { FilesystemStorageAdapter } from './fs-storage-adapter';
import type { StorageAdapter } from './storage-adapter';

export interface RetentionConfig {
  maxSprints: number;
  archiveExpired: boolean;
  archiveDir?: string;
}

export const DEFAULT_RETENTION_CONFIG: RetentionConfig = {
  maxSprints: 5,
  archiveExpired: false,
};

export class TelemetryRetentionManager {
  private readonly adapter: StorageAdapter;

  constructor(
    private readonly config: RetentionConfig = DEFAULT_RETENTION_CONFIG,
    adapter?: StorageAdapter
  ) {
    this.adapter = adapter ?? new FilesystemStorageAdapter();
  }

  async enforce(telemetryDir: string): Promise<void> {
    if (!this.adapter.exists(telemetryDir)) {
      return;
    }

    const maxSprints = Math.max(0, this.config.maxSprints);
    const files = this.adapter
      .readDir(telemetryDir)
      .filter((fileName) => fileName.startsWith('sprint-') && fileName.endsWith('.json'))
      .map((fileName) => {
        const filePath = path.join(telemetryDir, fileName);
        const stat = this.adapter.stat(filePath);
        return {
          filePath,
          mtimeMs: stat.mtimeMs,
        };
      })
      .sort((a, b) => a.mtimeMs - b.mtimeMs);

    if (files.length <= maxSprints) {
      return;
    }

    const expired = files.slice(0, files.length - maxSprints);
    for (const entry of expired) {
      if (this.config.archiveExpired) {
        await this.archive(entry.filePath, this.config.archiveDir ?? telemetryDir);
      }
      this.adapter.rm(entry.filePath);
    }
  }

  async archive(filePath: string, archiveDir: string): Promise<string> {
    this.adapter.mkdir(archiveDir, { recursive: true });
    const archivePath = path.join(archiveDir, `${path.basename(filePath)}l.gz`);
    const content = this.adapter.readBytes(filePath);
    const compressed = zlib.gzipSync(content);
    this.adapter.writeBytes(archivePath, compressed);
    return archivePath;
  }
}
