import * as path from 'path';
import { z } from 'zod';
import { ArchitecturePlanSchema } from './architecture-plan';
import { EnforcementReportSchema } from './architecture-enforcer';
import { PlanRevisionTriggerSchema, type PlanRevisionTrigger } from './plan-revision';
import { SprintTaskPlanSchema, TaskScheduleSchema } from './task-decomposition';
import { AgentPersona, type WorkspaceState } from './types';
import { WorkspaceManager } from './workspace';
import { FilesystemStorageAdapter } from './fs-storage-adapter';
import type { StorageAdapter } from './storage-adapter';

// ─── Sprint State Schemas ─────────────────────────────────────────────────────

export const SprintCheckpointSchema = z.object({
  checkpointId: z.string().min(1),
  sprintId: z.string().min(1),
  runId: z.string().min(1),
  activeSprintPlanId: z.string().min(1),
  activeGlobalPlanId: z.string().min(1),
  revisionCount: z.number().int().min(0),
  completedTaskIds: z.array(z.string().min(1)),
  blockedTaskIds: z.array(z.string().min(1)),
  remainingTaskSchedule: TaskScheduleSchema,
  lastCompletedGroupId: z.number().int().positive().optional(),
  createdAt: z.string().datetime(),
});

export const PlannedSprintStateSchema = z.object({
  currentSprintPlan: ArchitecturePlanSchema,
  currentGlobalPlanId: z.string().min(1),
  taskPlan: SprintTaskPlanSchema,
  runId: z.string().min(1),
  revisionCount: z.number().int().min(0),
  maxRevisions: z.number().int().positive().default(1),
  storyRevisionCounts: z.record(z.string(), z.number().int().min(0)).default({}),
  maxRevisionsPerStory: z.number().int().positive().default(1),
  checkpoint: SprintCheckpointSchema.optional(),
  enforcementReports: z.array(EnforcementReportSchema).default([]),
});

// ─── Types ────────────────────────────────────────────────────────────────────

export type SprintCheckpoint = z.infer<typeof SprintCheckpointSchema>;
export type PlannedSprintState = z.infer<typeof PlannedSprintStateSchema>;

// ─── Human Gate ───────────────────────────────────────────────────────────────

export interface HumanGate {
  requestApproval(trigger: PlanRevisionTrigger): Promise<boolean>;
}

export class DefaultHumanGate implements HumanGate {
  async requestApproval(_trigger: PlanRevisionTrigger): Promise<boolean> {
    throw new Error(
      'Human approval required — no interactive gate configured. Set a HumanGate implementation on OrchestratorConfig.'
    );
  }
}

export const GateConfigSchema = z.object({
  after: z.nativeEnum(AgentPersona),
  requireApproval: z.enum(['always', 'on-cross-service', 'on-breaking-change', 'never']),
  notifyVia: z.enum(['cli-prompt']).optional(),
});

export type GateConfig = z.infer<typeof GateConfigSchema>;

// ─── Sprint Checkpoint Manager ────────────────────────────────────────────────

const SPRINT_CHECKPOINT_FILE = 'sprint-checkpoint.json';

export class SprintCheckpointManager {
  private readonly adapter: StorageAdapter;

  constructor(private readonly workspaceManager: WorkspaceManager, adapter?: StorageAdapter) {
    this.adapter = adapter ?? new FilesystemStorageAdapter();
  }

  save(ws: WorkspaceState, checkpoint: SprintCheckpoint): void {
    const validated = SprintCheckpointSchema.parse(checkpoint);
    this.workspaceManager.writeFile(ws, SPRINT_CHECKPOINT_FILE, JSON.stringify(validated, null, 2));
  }

  load(ws: WorkspaceState): SprintCheckpoint | null {
    try {
      const raw = this.workspaceManager.readFile(ws, SPRINT_CHECKPOINT_FILE);
      return SprintCheckpointSchema.parse(JSON.parse(raw));
    } catch {
      return null;
    }
  }

  clear(ws: WorkspaceState): void {
    const fullPath = path.join(ws.basePath, SPRINT_CHECKPOINT_FILE);
    if (this.adapter.exists(fullPath)) {
      this.adapter.rm(fullPath);
    }
    delete ws.files[SPRINT_CHECKPOINT_FILE];
  }

  exists(ws: WorkspaceState): boolean {
    return this.adapter.exists(path.join(ws.basePath, SPRINT_CHECKPOINT_FILE));
  }
}

export { PlanRevisionTriggerSchema };
