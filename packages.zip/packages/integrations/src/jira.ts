import {
  StoryState,
  StorySource,
  type Story,
} from '@splinty/core';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface JiraConfig {
  baseUrl: string;  // e.g. "https://mycompany.atlassian.net"
  email: string;
  apiToken: string;
}

export interface JiraIssue {
  id: string;
  key: string;
  fields: {
    summary: string;
    description?: {
      content?: Array<{
        content?: Array<{ text?: string }>;
      }>;
    } | string | null;
    status?: { name?: string };
    priority?: { name?: string };
    story_points?: number;
    labels?: string[];
    [key: string]: unknown;
  };
}

export interface JiraTransition {
  id: string;
  name: string;
  to: { name: string };
}

// ─── Custom Errors ────────────────────────────────────────────────────────────

export class AuthError extends Error {
  constructor(url: string) {
    super(`AuthError: 401 Unauthorized for ${url}. Check email and API token.`);
    this.name = 'AuthError';
  }
}

export class NotFoundError extends Error {
  constructor(url: string) {
    super(`NotFoundError: 404 Not Found for ${url}`);
    this.name = 'NotFoundError';
  }
}

export class RateLimitError extends Error {
  constructor(url: string, retriesExhausted: number) {
    super(`RateLimitError: 429 Too Many Requests for ${url} after ${retriesExhausted} retries`);
    this.name = 'RateLimitError';
  }
}

// ─── ADF (Atlassian Document Format) Types ────────────────────────────────────

export interface AdfNode {
  type: string;
  content?: AdfNode[];
  text?: string;
  marks?: Array<{ type: string; attrs?: Record<string, unknown> }>;
  attrs?: Record<string, unknown>;
}

export interface AdfDocument {
  type: 'doc';
  version: 1;
  content: AdfNode[];
}

// ─── ADF Factory Functions ────────────────────────────────────────────────────

/**
 * Build an ADF description for a story issue.
 * Format: Title + Acceptance Criteria bullet list.
 */
export function buildStoryDescription(title: string, acceptanceCriteria: string[]): AdfDocument {
  const content: AdfNode[] = [
    {
      type: 'paragraph',
      content: [{ type: 'text', text: title }],
    },
  ];

  if (acceptanceCriteria.length > 0) {
    content.push({
      type: 'paragraph',
      content: [
        { type: 'text', text: 'Acceptance Criteria:', marks: [{ type: 'strong' }] },
      ],
    });
    content.push({
      type: 'bulletList',
      content: acceptanceCriteria.map((criterion) => ({
        type: 'listItem',
        content: [
          {
            type: 'paragraph',
            content: [{ type: 'text', text: criterion }],
          },
        ],
      })),
    });
  }

  return { type: 'doc', version: 1, content };
}

/**
 * Build an ADF description for a bug issue.
 * Format: Steps to reproduce + Expected/Actual behavior.
 */
export function buildBugDescription(
  stepsToReproduce: string,
  expectedBehavior: string,
  actualBehavior: string
): AdfDocument {
  return {
    type: 'doc',
    version: 1,
    content: [
      {
        type: 'paragraph',
        content: [
          { type: 'text', text: 'Steps to Reproduce:', marks: [{ type: 'strong' }] },
        ],
      },
      {
        type: 'paragraph',
        content: [{ type: 'text', text: stepsToReproduce }],
      },
      {
        type: 'paragraph',
        content: [
          { type: 'text', text: 'Expected Behavior:', marks: [{ type: 'strong' }] },
        ],
      },
      {
        type: 'paragraph',
        content: [{ type: 'text', text: expectedBehavior }],
      },
      {
        type: 'paragraph',
        content: [
          { type: 'text', text: 'Actual Behavior:', marks: [{ type: 'strong' }] },
        ],
      },
      {
        type: 'paragraph',
        content: [{ type: 'text', text: actualBehavior }],
      },
    ],
  };
}

/**
 * Build an ADF comment for QA test results.
 * Format: Status + Test results bullet list.
 */
export function buildQaResultComment(
  status: 'PASS' | 'FAIL',
  testResults: string[]
): AdfDocument {
  const statusEmoji = status === 'PASS' ? '✅' : '❌';
  const content: AdfNode[] = [
    {
      type: 'paragraph',
      content: [
        { type: 'text', text: `${statusEmoji} QA Results: ${status}`, marks: [{ type: 'strong' }] },
      ],
    },
  ];

  if (testResults.length > 0) {
    content.push({
      type: 'bulletList',
      content: testResults.map((result) => ({
        type: 'listItem',
        content: [
          {
            type: 'paragraph',
            content: [{ type: 'text', text: result }],
          },
        ],
      })),
    });
  }

  return { type: 'doc', version: 1, content };
}

// ─── JiraConnector ────────────────────────────────────────────────────────────

export class JiraConnector {
  private readonly baseUrl: string;
  private readonly authHeader: string;

  constructor(config: JiraConfig) {
    this.baseUrl = config.baseUrl.replace(/\/$/, '');
    const encoded = Buffer.from(`${config.email}:${config.apiToken}`).toString('base64');
    this.authHeader = `Basic ${encoded}`;
  }

  /**
   * Fetch stories from a Jira board, optionally filtered by sprint.
   * JQL: project = BOARD-1 AND sprint = <sprintId> ORDER BY created DESC
   */
  async fetchStories(boardId: string, sprintId?: string): Promise<Story[]> {
    let jql = `project = "${boardId}"`;
    if (sprintId) {
      jql += ` AND sprint = "${sprintId}"`;
    }
    jql += ' ORDER BY created DESC';

    const url = `${this.baseUrl}/rest/api/3/search?jql=${encodeURIComponent(jql)}`;
    const data = await this.request<{ issues: JiraIssue[] }>(url, 'GET');
    return (data.issues ?? []).map((issue) => this.parseJiraIssue(issue));
  }

  /**
   * Maps a Jira issue to the Story type.
   */
  parseJiraIssue(issue: JiraIssue): Story {
    const now = new Date().toISOString();
    const description = this.extractDescription(issue.fields.description);
    return {
      id: `jira-${issue.key}`,
      title: issue.fields.summary,
      description,
      acceptanceCriteria: [],
      dependsOn: [],
      state: StoryState.RAW,
      source: StorySource.JIRA,
      sourceId: issue.key,
      workspacePath: '',
      domain: 'general',
      tags: issue.fields.labels ?? [],
      createdAt: now,
      updatedAt: now,
    };
  }

  /**
   * Add a comment to a Jira issue.
   */
  async addComment(issueKey: string, body: string): Promise<void> {
    const url = `${this.baseUrl}/rest/api/3/issue/${issueKey}/comment`;
    await this.request<unknown>(url, 'POST', {
      body: {
        type: 'doc',
        version: 1,
        content: [
          {
            type: 'paragraph',
            content: [{ type: 'text', text: body }],
          },
        ],
      },
    });
  }

  /**
   * Add a comment to a Jira issue using ADF.
   */
  async addAdfComment(issueKey: string, adfDocument: AdfDocument): Promise<void> {
    const url = `${this.baseUrl}/rest/api/3/issue/${issueKey}/comment`;
    await this.request<unknown>(url, 'POST', { body: adfDocument });
  }

  /**
   * Create a new issue and return its key.
   */
  async createIssue(
    projectKey: string,
    summary: string,
    description: AdfDocument,
    issueType: string = 'Task'
  ): Promise<string> {
    const url = `${this.baseUrl}/rest/api/3/issue`;
    const payload = {
      fields: {
        project: { key: projectKey },
        summary,
        description,
        issuetype: { name: issueType },
      },
    };
    const response = await this.request<{ key: string }>(url, 'POST', payload);
    return response.key;
  }

  /**
   * Create a bug issue and return its key.
   */
  async createBugIssue(
    projectKey: string,
    summary: string,
    description: AdfDocument
  ): Promise<string> {
    return this.createIssue(projectKey, summary, description, 'Bug');
  }

  /**
   * Get field metadata for a project.
   */
  async getFieldMetadata(projectKey: string): Promise<Record<string, unknown>> {
    const url = `${this.baseUrl}/rest/api/3/issue/createmeta?projectKeys=${projectKey}&expand=projects.issuetypes.fields`;
    return this.request<Record<string, unknown>>(url, 'GET');
  }

  /**
   * Transition a Jira issue to a new status.
   */
  async updateStatus(issueKey: string, transitionId: string): Promise<void> {
    const url = `${this.baseUrl}/rest/api/3/issue/${issueKey}/transitions`;
    await this.request<unknown>(url, 'POST', {
      transition: { id: transitionId },
    });
  }

  /**
   * Get available transitions for an issue.
   */
  async getTransitions(issueKey: string): Promise<JiraTransition[]> {
    const url = `${this.baseUrl}/rest/api/3/issue/${issueKey}/transitions`;
    const data = await this.request<{ transitions: JiraTransition[] }>(url, 'GET');
    return data.transitions ?? [];
  }

  // ── Private helpers ────────────────────────────────────────────────────────

  private async request<T>(url: string, method: string, body?: unknown): Promise<T> {
    const maxRetries = 3;
    let lastError: Error | null = null;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      const headers: Record<string, string> = {
        Authorization: this.authHeader,
        'Content-Type': 'application/json',
        Accept: 'application/json',
      };

      const init: RequestInit = { method, headers };
      if (body) {
        init.body = JSON.stringify(body);
      }

      let response: Response;
      try {
        response = await fetch(url, init);
      } catch (err) {
        throw new Error(`JiraConnector: network error for ${url}: ${(err as Error).message}`);
      }

      if (response.status === 401) throw new AuthError(url);
      if (response.status === 404) throw new NotFoundError(url);

      if (response.status === 429) {
        if (attempt === maxRetries) {
          throw new RateLimitError(url, maxRetries);
        }

        const retryAfterHeader = response.headers.get('Retry-After');
        let delayMs: number;
        if (retryAfterHeader) {
          const retryAfterSeconds = parseInt(retryAfterHeader, 10);
          if (!isNaN(retryAfterSeconds)) {
            delayMs = retryAfterSeconds * 1000;
          } else {
            const retryAfterDate = new Date(retryAfterHeader);
            if (!isNaN(retryAfterDate.getTime())) {
              delayMs = Math.max(0, retryAfterDate.getTime() - Date.now());
            } else {
              delayMs = Math.pow(2, attempt) * 1000;
            }
          }
        } else {
          delayMs = Math.pow(2, attempt) * 1000;
        }

        await new Promise((resolve) => setTimeout(resolve, delayMs));
        lastError = new Error(`429 Too Many Requests (attempt ${attempt + 1}/${maxRetries + 1})`);
        continue;
      }

      if (!response.ok) {
        throw new Error(`JiraConnector: unexpected status ${response.status} for ${url}`);
      }

      if (response.status === 204) return undefined as unknown as T;

      const text = await response.text();
      if (!text.trim()) return undefined as unknown as T;

      try {
        return JSON.parse(text) as T;
      } catch {
        throw new Error(`JiraConnector: invalid JSON response from ${url}`);
      }
    }

    throw lastError ?? new Error('JiraConnector: unexpected retry exhaustion');
  }

  private extractDescription(
    desc: JiraIssue['fields']['description']
  ): string {
    if (!desc) return '';
    if (typeof desc === 'string') return desc;
    // Atlassian Document Format (ADF) — extract text nodes
    return (desc.content ?? [])
      .flatMap((block) => block.content ?? [])
      .map((node) => node.text ?? '')
      .join('')
      .trim();
  }
}
