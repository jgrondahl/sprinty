#!/usr/bin/env bun
/**
 * Splinty CLI — sprint orchestrator command-line interface
 *
 * Commands:
 *   splinty init --name <project-name>
 *   splinty run --source <file|jira|github> --input <path|board-id|repo>
 *   splinty status [--project <project-id>]
 *   splinty --help
 *
 * Exit codes:
 *   0  success
 *   1  any story BLOCKED
 *   2  fatal error
 */

import * as path from 'path';
import * as fs from 'fs';
import { LedgerManager, type Story, type HandoffDocument, StorySource } from '@splinty/core';
import { SprintOrchestrator, GitHubCopilotClient } from '@splinty/agents';
import {
  FileConnector,
  JiraConnector,
  GitHubConnector,
  buildQaResultComment,
  buildBugDescription,
  buildStoryDescription,
} from '@splinty/integrations';
import { SplintyApiClient } from './api-client';

// ─── ANSI colors ──────────────────────────────────────────────────────────────

const GREEN  = '\x1b[32m';
const YELLOW = '\x1b[33m';
const RED    = '\x1b[31m';
const RESET  = '\x1b[0m';

function green(s: string)  { return `${GREEN}${s}${RESET}`; }
function yellow(s: string) { return `${YELLOW}${s}${RESET}`; }
function red(s: string)    { return `${RED}${s}${RESET}`; }

function colorState(state: string): string {
  const upper = state.toUpperCase();
  if (['DONE', 'MERGED', 'PR_OPEN'].includes(upper)) return green(state);
  if (['IN_PROGRESS', 'IN_REVIEW', 'SPRINT_READY', 'REFINED'].includes(upper)) return yellow(state);
  if (['BLOCKED', 'ERROR'].includes(upper)) return red(state);
  return state;
}

// ─── Arg parsing helpers ──────────────────────────────────────────────────────

function parseArgs(argv: string[]): { command: string; flags: Record<string, string> } {
  // argv[0] = 'bun' or binary path, argv[1] = script path, argv[2+] = user args
  const userArgs = argv.slice(2);
  const command = userArgs[0] ?? 'help';
  const flags: Record<string, string> = {};

  for (let i = 1; i < userArgs.length; i++) {
    const arg = userArgs[i]!;
    if (arg.startsWith('--')) {
      const eqIndex = arg.indexOf('=');
      if (eqIndex > 2) {
        const key = arg.slice(2, eqIndex);
        const value = arg.slice(eqIndex + 1);
        flags[key] = value;
        continue;
      }
      const key = arg.slice(2);
      const value = userArgs[i + 1] && !userArgs[i + 1]!.startsWith('--')
        ? userArgs[++i]!
        : 'true';
      flags[key] = value;
    }
  }

  return { command, flags };
}

// ─── Base workspace dir (env override or default) ─────────────────────────────

function workspaceBaseDir(): string {
  return process.env['SPLINTY_WORKSPACE_DIR'] ?? '.splinty';
}

// ─── Commands ─────────────────────────────────────────────────────────────────

/**
 * splinty init --name <project-name>
 */
export function cmdInit(flags: Record<string, string>): number {
  const name = flags['name'];
  if (!name) {
    console.error(red('Error: --name is required\n  Usage: splinty init --name <project-name>'));
    return 2;
  }

  const baseDir = workspaceBaseDir();
  const ledger = new LedgerManager(baseDir);

  try {
    ledger.init(name);
  } catch (err) {
    // Already initialised is fine — check if AGENTS.md exists
    const agentsMd = path.join(baseDir, name, 'AGENTS.md');
    if (!fs.existsSync(agentsMd)) {
      console.error(red(`Error: failed to initialize workspace: ${(err as Error).message}`));
      return 2;
    }
  }

  const agentsMd = path.join(baseDir, name, 'AGENTS.md');
  console.log(green(`✓ Workspace initialized`));
  console.log(`  Project : ${name}`);
  console.log(`  Ledger  : ${agentsMd}`);
  console.log(`\nNext steps:`);
  console.log(`  Set required env vars:`);
  console.log(`    ANTHROPIC_API_KEY  — Claude API key`);
  console.log(`    JIRA_BASE_URL      — Jira instance URL (if using Jira source)`);
  console.log(`    JIRA_EMAIL         — Jira account email`);
  console.log(`    JIRA_API_TOKEN     — Jira API token`);
  console.log(`    GITHUB_TOKEN       — GitHub personal access token (if using GitHub source)`);
  return 0;
}

/**
 * splinty run --source <file|jira|github> --input <path|board-id|repo>
 */
export async function cmdRun(flags: Record<string, string>): Promise<number> {
  const source = flags['source'];
  const input  = flags['input'];
  const project = flags['project'] ?? 'default';
  const apiMode = flags['api'] === 'true';

  if (!source || !input) {
    console.error(red('Error: --source and --input are required'));
    console.error('  Usage: splinty run --source <file|jira|github> --input <path|board-id|repo>');
    return 2;
  }

  if (apiMode) {
    const baseUrl = process.env['SPLINTY_API_URL'] ?? 'http://localhost:3000';
    const credentials = SplintyApiClient.loadCredentials();
    if (!credentials?.token) {
      console.error(red('Error: no API credentials found. Run `splinty login` first.'));
      return 2;
    }

    const client = new SplintyApiClient(baseUrl, credentials.token);

    if (source === 'file') {
      if (!fs.existsSync(input)) {
        console.error(red(`Error: file not found: ${input}`));
        return 2;
      }

      const text = fs.readFileSync(input, 'utf-8');
      let parsed: unknown;
      try {
        parsed = JSON.parse(text);
      } catch {
        console.error(red('Error: --api mode with --source file expects JSON roadmap payload'));
        return 2;
      }

      try {
        const result = await client.importRoadmap(project, parsed);
        console.log(JSON.stringify(result, null, 2));
        return 0;
      } catch (err) {
        console.error(red(`Error importing roadmap via API: ${(err as Error).message}`));
        return 2;
      }
    }

    if (source === 'jira' || source === 'github') {
      console.error(red('Error: --api mode currently supports --source file only'));
      return 2;
    }
  }

  // ── Resolve project spec (docs/AGENTS.md hard constraints) ────────────────
  // Explicit --spec flag takes precedence; otherwise auto-discover docs/AGENTS.md
  // relative to the input file's directory (for file source) or CWD.
  let projectSpec: string | undefined;
  const specFlagPath = flags['spec'];
  if (specFlagPath) {
    const specAbsPath = path.resolve(specFlagPath);
    if (fs.existsSync(specAbsPath)) {
      projectSpec = fs.readFileSync(specAbsPath, 'utf-8');
      console.log(`Using project spec: ${specAbsPath}`);
    } else {
      console.error(red(`Error: spec file not found: ${specAbsPath}`));
      return 2;
    }
  } else {
    // Auto-discover: look for docs/AGENTS.md relative to input file dir or CWD
    const searchBase = source === 'file' ? path.dirname(path.resolve(input)) : process.cwd();
    const candidates = [
      path.join(searchBase, 'docs', 'AGENTS.md'),
      path.join(searchBase, '..', 'docs', 'AGENTS.md'),
      path.join(process.cwd(), 'docs', 'AGENTS.md'),
    ];
    for (const candidate of candidates) {
      if (fs.existsSync(candidate)) {
        projectSpec = fs.readFileSync(candidate, 'utf-8');
        console.log(`Auto-detected project spec: ${candidate}`);
        break;
      }
    }
  }

  // ── Load stories ───────────────────────────────────────────────────────────
  let stories;
  try {
    if (source === 'file') {
      const connector = new FileConnector();
      stories = connector.parse(path.resolve(input));
    } else if (source === 'jira') {
      const jiraBaseUrl  = process.env['JIRA_BASE_URL'];
      const jiraEmail    = process.env['JIRA_EMAIL'];
      const jiraApiToken = process.env['JIRA_API_TOKEN'];
      if (!jiraBaseUrl || !jiraEmail || !jiraApiToken) {
        console.error(red('Error: JIRA_BASE_URL, JIRA_EMAIL, and JIRA_API_TOKEN env vars are required for Jira source'));
        return 2;
      }
      const connector = new JiraConnector({ baseUrl: jiraBaseUrl, email: jiraEmail, apiToken: jiraApiToken });
      stories = await connector.fetchStories(input);
    } else if (source === 'github') {
      const token = process.env['GITHUB_TOKEN'];
      if (!token) {
        console.error(red('Error: GITHUB_TOKEN env var is required for GitHub source'));
        return 2;
      }
      const [owner, repo] = input.split('/');
      if (!owner || !repo) {
        console.error(red('Error: --input for GitHub source must be in <owner/repo> format'));
        return 2;
      }
      const connector = new GitHubConnector({ owner: owner!, repo: repo!, token });
      stories = await connector.fetchIssues();
    } else {
      console.error(red(`Error: unknown source "${source}". Must be file, jira, or github`));
      return 2;
    }
  } catch (err) {
    console.error(red(`Error loading stories: ${(err as Error).message}`));
    return 2;
  }

  if (!stories || stories.length === 0) {
    console.error(yellow('Warning: no stories found in source'));
    return 0;
  }

  console.log(`Running pipeline for ${stories.length} story/stories...`);

  // ── Resolve LLM provider ──────────────────────────────────────────────────
  const copilotClient = new GitHubCopilotClient();
  const hasAnthropicKey = !!process.env['ANTHROPIC_API_KEY'];
  const hasCopilotToken = copilotClient.isAuthenticated();

  if (!hasAnthropicKey && !hasCopilotToken) {
    console.error(red('Error: no LLM provider configured.'));
    console.error('  Either set ANTHROPIC_API_KEY or run `splinty auth` for GitHub Copilot.');
    return 2;
  }

  const useCopilot = hasCopilotToken && !hasAnthropicKey;
  if (useCopilot) {
    console.log('Using GitHub Copilot as LLM provider (gpt-4o)');
  }

  // ── Determine write-back configuration ─────────────────────────────────────
  const noWriteback = flags['no-writeback'] === 'true';
  const writebackEnabled = process.env['JIRA_WRITEBACK_ENABLED'] === 'true' && !noWriteback;

  // ── Run orchestrator ───────────────────────────────────────────────────────
  const baseDir = workspaceBaseDir();
  const orch = new SprintOrchestrator({
    projectId: project,
    workspaceBaseDir: baseDir,
    ...(useCopilot
      ? { defaultClient: copilotClient, defaultModel: 'gpt-4o', lightModel: 'gpt-4o-mini' }
      : {}),
    ...(projectSpec ? { projectSpec } : {}),
    ...(writebackEnabled ? { writeBackStory } : {}),
  });

  let results;
  try {
    results = await orch.run(stories);
  } catch (err) {
    console.error(red(`Fatal error: ${(err as Error).message}`));
    return 2;
  }

  // ── Report ─────────────────────────────────────────────────────────────────
  let blocked = false;
  for (const result of results) {
    if (result.testResults.failed > 0) {
      console.log(red(`  ✗ ${result.storyId}  BLOCKED`));
      blocked = true;
    } else {
      const prLine = result.prUrl ? `  PR: ${result.prUrl}` : '';
      console.log(green(`  ✓ ${result.storyId}  branch: ${result.gitBranch}${prLine}`));
    }
  }

  return blocked ? 1 : 0;
}

export async function cmdLogin(flags: Record<string, string>): Promise<number> {
  const email = flags['email'];
  const password = flags['password'];
  const orgId = flags['org'];

  if (!email || !password) {
    console.error(red('Error: --email and --password are required'));
    return 2;
  }

  const baseUrl = process.env['SPLINTY_API_URL'] ?? 'http://localhost:3000';
  const client = new SplintyApiClient(baseUrl);

  try {
    const creds = await client.login(email, password, orgId);
    await SplintyApiClient.saveCredentials(creds);
    console.log(green('✓ API login successful'));
    console.log(`  Org: ${creds.orgId}`);
    return 0;
  } catch (err) {
    console.error(red(`Error: ${(err as Error).message}`));
    return 2;
  }
}

export async function cmdProjects(flags: Record<string, string>): Promise<number> {
  const action = flags['action'] ?? 'list';
  if (action !== 'list') {
    console.error(red('Error: only --action list is supported'));
    return 2;
  }

  const baseUrl = process.env['SPLINTY_API_URL'] ?? 'http://localhost:3000';
  const credentials = SplintyApiClient.loadCredentials();
  if (!credentials?.token) {
    console.error(red('Error: no API credentials found. Run `splinty login` first.'));
    return 2;
  }

  const client = new SplintyApiClient(baseUrl, credentials.token);
  try {
    const result = await client.listProjects();
    console.log(JSON.stringify(result, null, 2));
    return 0;
  } catch (err) {
    console.error(red(`Error: ${(err as Error).message}`));
    return 2;
  }
}

/**
 * splinty status [--project <project-id>]
 */
export function cmdStatus(flags: Record<string, string>): number {
  const project = flags['project'] ?? 'default';
  const baseDir = workspaceBaseDir();
  const ledger  = new LedgerManager(baseDir);

  let rows: Array<{ id: string; title: string; state: string; updatedAt: string }>;
  try {
    rows = ledger.load(project);
  } catch (err) {
    console.error(red(`Error: ${(err as Error).message}`));
    console.error(`  Run: splinty init --name ${project}`);
    return 2;
  }

  if (rows.length === 0) {
    console.log(yellow('No stories found in sprint ledger.'));
    return 0;
  }

  console.log(`\nSprint board — project: ${project}\n`);
  const COL_ID    = 20;
  const COL_TITLE = 50;
  const COL_STATE = 20;
  const COL_DATE  = 12;

  const header = `${'ID'.padEnd(COL_ID)}  ${'Title'.padEnd(COL_TITLE)}  ${'State'.padEnd(COL_STATE)}  ${'Updated'.padEnd(COL_DATE)}`;
  const divider = '-'.repeat(header.length);

  console.log(header);
  console.log(divider);

  for (const row of rows) {
    const idCol    = row.id.padEnd(COL_ID);
    const titleCol = row.title.slice(0, COL_TITLE).padEnd(COL_TITLE);
    const stateCol = colorState(row.state);
    const dateCol  = row.updatedAt.slice(0, COL_DATE);
    console.log(`${idCol}  ${titleCol}  ${stateCol.padEnd(COL_STATE + 10)}  ${dateCol}`);
  }

  console.log();
  return 0;
}

export function cmdExport(flags: Record<string, string>): number {
  const format = flags['format'] ?? 'json';
  const sprintId = flags['sprint'];
  const project = flags['project'] ?? 'default';

  if (format !== 'json') {
    console.error(red(`Error: unsupported --format "${format}". Only json is supported.`));
    return 2;
  }

  if (!sprintId) {
    console.error(red('Error: --sprint is required'));
    console.error('  Usage: splinty export --format=json --sprint=<id> [--project <id>]');
    return 2;
  }

  const telemetryDir = path.join(workspaceBaseDir(), project, 'stories', 'sprint', 'artifacts', 'telemetry');
  if (!fs.existsSync(telemetryDir)) {
    console.error(red(`Error: telemetry directory not found: ${telemetryDir}`));
    return 1;
  }

  const prefix = `sprint-${sprintId}-`;
  const matchingFiles = fs
    .readdirSync(telemetryDir)
    .filter((fileName) => fileName.startsWith(prefix) && fileName.endsWith('.json'))
    .sort();

  if (matchingFiles.length === 0) {
    console.error(red(`Error: no telemetry files found for sprint ${sprintId}`));
    return 1;
  }

  if (matchingFiles.length === 1) {
    const filePath = path.join(telemetryDir, matchingFiles[0]!);
    process.stdout.write(fs.readFileSync(filePath, 'utf-8'));
    return 0;
  }

  const payload = matchingFiles.map((fileName) => {
    const filePath = path.join(telemetryDir, fileName);
    return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  });
  process.stdout.write(`${JSON.stringify(payload, null, 2)}\n`);
  return 0;
}

/**
 * splinty auth [--force] [--logout]
 *
 * Runs the GitHub OAuth device flow to authenticate with GitHub Copilot.
 * Stores the resulting token at ~/.splinty/copilot-token.json.
 *
 * Flags:
 *   --force   Re-run device flow even if a token is already cached
 *   --logout  Remove the cached token
 */
export async function cmdAuth(flags: Record<string, string>): Promise<number> {
  const client = new GitHubCopilotClient();

  if (flags['logout'] === 'true') {
    client.logout();
    return 0;
  }

  const force = flags['force'] === 'true';
  try {
    await client.login(force);
  } catch (err) {
    console.error(red(`Error: ${(err as Error).message}`));
    return 2;
  }
  return 0;
}

/**
 * splinty --help
 */
export function cmdHelp(): number {
  console.log(`
Splinty — AI-powered SCRUM sprint pipeline

USAGE
  splinty <command> [options]

COMMANDS
  auth    Authenticate with GitHub Copilot (device flow)
  login   Authenticate against Splinty API and store credentials
  projects  Project operations via Splinty API
  export  Export sprint telemetry artifacts
  init    Create a new project workspace
  run     Load stories and run the full pipeline
  status  Print the current sprint board
  --help  Show this help

AUTH
  splinty auth [--force] [--logout]

  Options:
    --force     Re-run device flow even if already authenticated
    --logout    Remove the cached GitHub Copilot token

  Token is stored at: ~/.splinty/copilot-token.json
  Requires a paid GitHub Copilot subscription (Pro, Pro+, Business, or Enterprise).

INIT
  splinty init --name <project-name>

  Options:
    --name <project-name>   Unique project identifier

RUN
  splinty run --source <file|jira|github> --input <path|board-id|repo>

  Options:
    --source file     Load stories from a .md/.json/.yaml file
    --source jira     Load stories from a Jira board
    --source github   Load stories from GitHub Issues
    --input <value>   File path, Jira board ID, or GitHub owner/repo
    --project <id>    Project ID to use (default: "default")
    --api             Route run through Splinty API client mode
    --spec <path>     Path to project spec file (AGENTS.md) with tech stack constraints.
                      Auto-discovered at docs/AGENTS.md if not specified.

  Required env vars (set before running):
    ANTHROPIC_API_KEY        Claude API key
    JIRA_BASE_URL            Jira instance URL  (--source jira)
    JIRA_EMAIL               Jira account email (--source jira)
    JIRA_API_TOKEN           Jira API token     (--source jira)
    GITHUB_TOKEN             GitHub token       (--source github)

API LOGIN
  splinty login --email <email> --password <password> [--org <org-id>]

PROJECTS
  splinty projects --action list

STATUS
  splinty status [--project <id>]

  Options:
    --project <id>    Project ID (default: "default")

EXPORT
  splinty export --format=json --sprint=<id> [--project <id>]

  Options:
    --format json     Output format (only json currently supported)
    --sprint <id>     Sprint ID to export (required)
    --project <id>    Project ID (default: "default")

EXAMPLES
  splinty init --name my-app
  splinty run --source file --input stories/sprint1.md --project my-app
  splinty run --source file --input roadmap.json --project my-app --api
  splinty run --source file --input stories/sprint1.md --project my-app --spec docs/AGENTS.md
  splinty run --source github --input owner/my-repo --project my-app
  splinty login --email user@example.com --password 'StrongPass123!'
  splinty projects --action list
  splinty status --project my-app
  splinty export --format=json --sprint=sprint-1736362052203 --project my-app

EXIT CODES
  0  All stories succeeded
  1  One or more stories BLOCKED
  2  Fatal error (misconfiguration, missing args, unrecoverable failure)
`);
  return 0;
}

/**
 * splinty create-story --title <title> --description <text>
 */
export async function cmdCreateStory(flags: Record<string, string>): Promise<number> {
  const title = flags['title'];
  const description = flags['description'] ?? flags['descriptionText'];
  const projectKey = process.env['JIRA_PROJECT_KEY'];

  if (!title || !description) {
    console.error(red('Error: --title and --description are required'));
    console.error('  Usage: splinty create-story --title <title> --description <text>');
    return 2;
  }

  if (!projectKey) {
    console.error(red('Error: JIRA_PROJECT_KEY env var is required'));
    return 2;
  }

  const jiraBaseUrl = process.env['JIRA_BASE_URL'];
  const jiraEmail = process.env['JIRA_EMAIL'];
  const jiraApiToken = process.env['JIRA_API_TOKEN'];

  if (!jiraBaseUrl || !jiraEmail || !jiraApiToken) {
    console.error(red('Error: JIRA_BASE_URL, JIRA_EMAIL, and JIRA_API_TOKEN env vars are required'));
    return 2;
  }

  try {
    const connector = new JiraConnector({
      baseUrl: jiraBaseUrl,
      email: jiraEmail,
      apiToken: jiraApiToken,
    });

    const descriptionAdf = buildStoryDescription(title, [description]);
    const issueKey = await connector.createIssue(projectKey, title, descriptionAdf, 'Story');
    console.log(green(`Created Jira story: ${issueKey}`));
    return 0;
  } catch (err) {
    console.error(red(`Error creating story: ${(err as Error).message}`));
    return 1;
  }
}

// ─── Write-back to Jira ──────────────────────────────────────────────────────

/**
 * Write back story QA results and bugs to Jira.
 * Only processes stories with source=JIRA and sourceId set.
 * 
 * @param story - The story to write back
 * @param handoff - The handoff document containing QA results
 * @param prUrl - Optional PR URL (unused in current implementation)
 */
export async function writeBackStory(
  story: Story,
  handoff: HandoffDocument,
  prUrl?: string
): Promise<void> {
  try {
    // Guard: only process Jira stories with sourceId
    if (story.source !== StorySource.JIRA || !story.sourceId) {
      console.warn(
        `[writeBackStory] Skipping non-Jira story or missing sourceId: ${story.id}`
      );
      return;
    }

    const issueKey = story.sourceId;

    // Parse stateOfWorld fields
    const verdict = (handoff.stateOfWorld['verdict'] ?? 'FAIL') as 'PASS' | 'FAIL' | 'BLOCKED';
    const passedAC = (handoff.stateOfWorld['passedAC'] ?? '').split('|').filter(Boolean);
    const failedAC = (handoff.stateOfWorld['failedAC'] ?? '').split('|').filter(Boolean);
    const bugsJson = handoff.stateOfWorld['bugs'] ?? '[]';
    let bugs: Array<{ description: string; severity: string }> = [];
    try {
      bugs = JSON.parse(bugsJson);
    } catch {
      console.warn(`[writeBackStory] Failed to parse bugs JSON for ${issueKey}`);
    }

    // Instantiate JiraConnector
    const jiraBaseUrl = process.env['JIRA_BASE_URL'];
    const jiraEmail = process.env['JIRA_EMAIL'];
    const jiraApiToken = process.env['JIRA_API_TOKEN'];

    if (!jiraBaseUrl || !jiraEmail || !jiraApiToken) {
      console.warn(
        '[writeBackStory] JIRA_BASE_URL, JIRA_EMAIL, or JIRA_API_TOKEN env vars not set'
      );
      return;
    }

    const connector = new JiraConnector({
      baseUrl: jiraBaseUrl,
      email: jiraEmail,
      apiToken: jiraApiToken,
    });

    // Post QA comment if verdict is not FAIL
    if (verdict !== 'FAIL') {
      try {
        const testResults: string[] = [];
        if (passedAC.length > 0) {
          testResults.push(`Passed: ${passedAC.join(', ')}`);
        }
        if (failedAC.length > 0) {
          testResults.push(`Failed: ${failedAC.join(', ')}`);
        }
        if (bugs.length > 0) {
          testResults.push(`Bugs found: ${bugs.length}`);
        }

        const qaComment = buildQaResultComment(verdict as 'PASS' | 'FAIL', testResults);
        await connector.addAdfComment(issueKey, qaComment);
        console.log(`[writeBackStory] Posted QA comment to ${issueKey}`);
      } catch (err) {
        console.warn(
          `[writeBackStory] Failed to post QA comment to ${issueKey}: ${(err as Error).message}`
        );
      }
    }

    // Transition to Done if verdict is PASS
    if (verdict === 'PASS') {
      try {
        const transitions = await connector.getTransitions(issueKey);
        const doneTransitionName = process.env['JIRA_DONE_TRANSITION_NAME'] ?? 'Done';
        const doneTransition = transitions.find(
          (t) => t.name.toLowerCase() === doneTransitionName.toLowerCase()
        );

        if (doneTransition) {
          await connector.updateStatus(issueKey, doneTransition.id);
          console.log(`[writeBackStory] Transitioned ${issueKey} to ${doneTransitionName}`);
        } else {
          console.warn(
            `[writeBackStory] Transition "${doneTransitionName}" not found for ${issueKey}`
          );
        }
      } catch (err) {
        console.warn(
          `[writeBackStory] Failed to transition ${issueKey}: ${(err as Error).message}`
        );
      }
    }

    // Create bug issues if PASS with bugs
    if (verdict === 'PASS' && bugs.length > 0) {
      const projectKey = issueKey.split('-')[0]!;

      for (const bug of bugs) {
        try {
          const bugSummary = `Bug: ${bug.description.slice(0, 100)}`;
          const bugDescription = buildBugDescription(
            bug.description,
            'Expected behavior per acceptance criteria',
            bug.description
          );
          const bugKey = await connector.createBugIssue(projectKey, bugSummary, bugDescription);
          console.log(`[writeBackStory] Created bug ${bugKey} for ${issueKey}`);
        } catch (err) {
          console.warn(
            `[writeBackStory] Failed to create bug for ${issueKey}: ${(err as Error).message}`
          );
        }
      }
    }
  } catch (err) {
    console.warn(
      `[writeBackStory] Unexpected error for ${story.id}: ${(err as Error).message}`
    );
  }
}

// ─── Entry point ──────────────────────────────────────────────────────────────

async function main(): Promise<void> {
  const { command, flags } = parseArgs(Bun.argv);

  let exitCode: number;

  if (command === 'auth') {
    exitCode = await cmdAuth(flags);
  } else if (command === 'login') {
    exitCode = await cmdLogin(flags);
  } else if (command === 'projects') {
    exitCode = await cmdProjects(flags);
  } else if (command === 'init') {
    exitCode = cmdInit(flags);
  } else if (command === 'run') {
    exitCode = await cmdRun(flags);
  } else if (command === 'status') {
    exitCode = cmdStatus(flags);
  } else if (command === 'export') {
    exitCode = cmdExport(flags);
  } else if (command === 'create-story') {
    exitCode = await cmdCreateStory(flags);
  } else if (command === '--help' || command === 'help' || command === '-h') {
    exitCode = cmdHelp();
  } else {
    console.error(red(`Unknown command: ${command}`));
    cmdHelp();
    exitCode = 2;
  }

  process.exit(exitCode);
}

// Only run main when executed directly (not when imported in tests)
if (import.meta.main) {
  main().catch((err) => {
    console.error(red(`Unhandled error: ${(err as Error).message}`));
    process.exit(2);
  });
}
